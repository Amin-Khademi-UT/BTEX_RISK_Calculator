"""Hand-checked tests, including back-calculation of the official EPA RSL air values."""
import math

import numpy as np
import pandas as pd
import pytest

from btex_risk import exposure, io
from btex_risk.config import DEFAULTS
from btex_risk.exposure import ParamSpec, Scenario, PRESETS, parse_scenarios
from btex_risk.toxicity import build_compounds, canonical_name

COMP = build_compounds({})


def scen(name):
    return parse_scenarios({"scenarios": {name: {"preset": name}}})[name]


def one_site(ca):
    idx = pd.MultiIndex.from_tuples([("S", k) for k in ca], names=["site", "compound"])
    return pd.DataFrame({"epc": list(ca.values())}, index=idx)


def test_ec_hq_elcr_by_hand_resident():
    # benzene 10 ug/m3, resident: ET 24, EF 350, ED 26, LT 70
    r = exposure.compute_risk(one_site({"benzene": 10.0}), {"resident": scen("resident")}, COMP).iloc[0]
    ec_nc = 10 * 24 * 350 * 26 / (26 * 365 * 24)       # = 9.589
    ec_c = 10 * 24 * 350 * 26 / (70 * 365 * 24)        # = 3.5616
    assert r.EC_nc == pytest.approx(ec_nc)
    assert r.EC_c == pytest.approx(ec_c)
    assert r.HQ == pytest.approx(ec_nc / (0.03 * 1000))          # 0.3196
    assert r.ELCR == pytest.approx(ec_c * 7.8e-6)                # 2.778e-5


def test_noncancer_hq_independent_of_ED():
    a = Scenario("a", ParamSpec(8), ParamSpec(250), ParamSpec(5))
    b = Scenario("b", ParamSpec(8), ParamSpec(250), ParamSpec(40))
    assert a.factor_nc() == pytest.approx(b.factor_nc())          # AT = ED cancels ED
    assert a.factor_c() < b.factor_c()                            # cancer scales with ED


@pytest.mark.parametrize("scenario,expected_c,expected_nc", [
    ("resident", 0.36, 31.0),    # EPA RSL resident air, benzene (TR=1E-6, THQ=1): 3.6E-01 / ~3.1E+01 ug/m3
    ("worker", 1.6, 131.0),      # EPA RSL composite-worker ambient air, benzene: 1.6E+00 / 1.3E+02 ug/m3
])
def test_benzene_matches_epa_rsl(scenario, expected_c, expected_nc):
    sl = exposure.screening_levels({"benzene": COMP["benzene"]}, {scenario: scen(scenario)}, 1e-6, 1.0).iloc[0]
    assert sl.SL_cancer_ugm3 == pytest.approx(expected_c, rel=0.03)
    assert sl.SL_noncancer_ugm3 == pytest.approx(expected_nc, rel=0.03)


def test_hazard_index_sums_and_target_organ():
    risk = exposure.compute_risk(one_site({"benzene": 20, "toluene": 100, "ethylbenzene": 10, "xylenes": 50}),
                                 {"worker": scen("worker")}, COMP)
    agg = exposure.aggregate(risk).iloc[0]
    assert agg.HI == pytest.approx(risk.HQ.sum())
    assert agg.ELCR == pytest.approx(risk.ELCR.sum())           # only benzene + ethylbenzene contribute
    neuro = risk[risk.target_organ == "neurological"].HQ.sum()   # toluene + xylenes
    assert agg.HI_max_organ >= neuro - 1e-12


def test_unit_conversion_ppb_to_ugm3():
    vm = io.molar_volume_l(25, 101.325)
    assert vm == pytest.approx(24.465, abs=0.01)
    assert io.to_ugm3(1.0, "ppb", 78.11, vm) == pytest.approx(3.193, abs=0.01)   # 1 ppb benzene
    assert io.to_ugm3(0.001, "mg/m3", 78.11, vm) == pytest.approx(1.0)
    assert io.to_ugm3(1000, "ng/m3", 78.11, vm) == pytest.approx(1.0)
    with pytest.raises(ValueError):
        io.to_ugm3(1, "furlongs", 78.11, vm)


def test_aliases_and_unknown_compound():
    assert canonical_name("Total Xylenes", COMP) == "xylenes"
    assert canonical_name(" Ethyl benzene ", COMP) == "ethylbenzene"
    with pytest.raises(KeyError):
        canonical_name("styrene", COMP)


def test_custom_compound_and_override():
    c = build_compounds({"compounds": {"benzene": {"iur": 2.2e-6}, "styrene": {"mw": 104.15, "rfc": 1.0}}})
    assert c["benzene"].iur == 2.2e-6 and c["benzene"].rfc == 0.03
    assert c["styrene"].rfc == 1.0 and c["styrene"].iur is None


def test_paramspec_parsing_and_sampling():
    p = ParamSpec.parse({"dist": "triangular", "min": 1, "mode": 4, "max": 10})
    assert p.value == 4
    x = p.sample(5000, np.random.default_rng(0))
    assert x.min() >= 1 and x.max() <= 10
    with pytest.raises(ValueError):
        ParamSpec.parse({"dist": "triangular", "min": 1, "max": 10})     # missing mode
    with pytest.raises(ValueError):
        ParamSpec.parse({"dist": "banana", "value": 1})


def test_ucl95_never_exceeds_max_and_small_n():
    conc = pd.DataFrame({"site": "S", "compound": "benzene", "conc_ugm3": [1.0, 1.1, 50.0],
                         "nondetect": False})
    epc = io.summarize_epc(conc, "ucl95")
    assert epc["epc"].iloc[0] <= 50.0 + 1e-9
    one = io.summarize_epc(conc.iloc[:1], "ucl95")
    assert one["epc"].iloc[0] == 1.0


def test_pipeline_end_to_end(tmp_path):
    from btex_risk import run
    res = run("configs/default.yaml", overrides={
        "project": {"output_dir": str(tmp_path)},
        "monte_carlo": {"n_iter": 500},
        "plots": {"which": ["dashboard", "tornado"], "formats": ["png"], "dpi": 60}})
    assert (tmp_path / "tables" / "risk_summary.csv").exists()
    assert (tmp_path / "report.html").exists()
    assert not res.agg.empty and np.isfinite(res.agg.HI).all()
    # Monte Carlo median should sit near the deterministic mean-based result (same order of magnitude)
    r = res.mc[(res.focus_site, "worker")]
    det = res.agg[(res.agg.site == res.focus_site) & (res.agg.scenario == "worker")].iloc[0]
    assert 0.2 < np.median(r.HI) / det.HI < 1.5


def test_monte_carlo_reproducible():
    from btex_risk import run
    ov = {"plots": {"enabled": False}, "monte_carlo": {"n_iter": 300, "seed": 5}}
    a = run("configs/default.yaml", ov, make_outputs=False)
    b = run("configs/default.yaml", ov, make_outputs=False)
    k = next(iter(a.mc))
    assert np.allclose(a.mc[k].HI, b.mc[k].HI)
