"""Generate the SYNTHETIC example dataset (data/example_synthetic_btex.csv).

These numbers are made up for demonstration only -- they are NOT measurements
and must not be cited as real data.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(2026)
VM = 8.314462618 * 298.15 / 101.325           # L/mol at 25 C, 1 atm
MW = {"Benzene": 78.11, "Toluene": 92.14, "Ethylbenzene": 106.17, "Xylenes": 106.17}

# site -> (geometric mean ug/m3 per compound, GSD, unit)
SITES = {
    "Pump island":        ({"Benzene": 55, "Toluene": 140, "Ethylbenzene": 22, "Xylenes": 85}, 1.55, "ug/m3"),
    "Station office":     ({"Benzene": 14, "Toluene": 38,  "Ethylbenzene": 6,  "Xylenes": 22}, 1.50, "ug/m3"),
    "Residential 50 m":   ({"Benzene": 5.5, "Toluene": 16, "Ethylbenzene": 2.4, "Xylenes": 9},  1.45, "ug/m3"),
    "Urban background":   ({"Benzene": 2.2, "Toluene": 7,  "Ethylbenzene": 1.0, "Xylenes": 4},  1.40, "ppb"),
}
N = 12
rows = []
for site, (gm, gsd, unit) in SITES.items():
    for comp, g in gm.items():
        x = np.exp(rng.normal(np.log(g), np.log(gsd), N))           # ug/m3
        for i, v in enumerate(x, 1):
            dl = 0.5 if unit == "ug/m3" else 0.15
            val = v if unit == "ug/m3" else v * VM / MW[comp]        # ppb
            nd = (val < dl)
            rows.append(dict(site=site, sample_id=f"{site[:3].upper()}-{i:02d}", compound=comp,
                             concentration=np.nan if nd else round(val, 3), unit=unit,
                             nondetect=nd, detection_limit=dl if nd else np.nan))
pd.DataFrame(rows).to_csv("data/example_synthetic_btex.csv", index=False)
print(len(rows), "rows written")
