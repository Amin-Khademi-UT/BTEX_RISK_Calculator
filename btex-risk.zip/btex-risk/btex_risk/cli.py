"""Command-line interface:  python -m btex_risk run --config configs/default.yaml"""
from __future__ import annotations

import argparse
import sys

from .pipeline import run


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="btex-risk", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the assessment")
    r.add_argument("-c", "--config", default=None, help="YAML config (optional; all keys have defaults)")
    r.add_argument("-d", "--data", help="concentration CSV (overrides config)")
    r.add_argument("-o", "--out", help="output directory (overrides config)")
    r.add_argument("--statistic", choices=["ucl95", "mean", "median", "p95", "max"])
    r.add_argument("--n-iter", type=int, help="Monte Carlo iterations")
    r.add_argument("--seed", type=int)
    r.add_argument("--no-mc", action="store_true", help="skip Monte Carlo")
    r.add_argument("--no-plots", action="store_true", help="tables only")
    r.add_argument("--style", choices=["dark", "light"])
    r.add_argument("--site", help="focus site for dashboard / MC plots")
    r.add_argument("--scenario", help="focus scenario")
    a = ap.parse_args(argv)

    o: dict = {}
    if a.data: o.setdefault("input", {})["concentrations_csv"] = a.data
    if a.out: o.setdefault("project", {})["output_dir"] = a.out
    if a.statistic: o.setdefault("input", {})["statistic"] = a.statistic
    if a.n_iter: o.setdefault("monte_carlo", {})["n_iter"] = a.n_iter
    if a.seed is not None: o.setdefault("monte_carlo", {})["seed"] = a.seed
    if a.no_mc: o.setdefault("monte_carlo", {})["enabled"] = False
    if a.no_plots: o.setdefault("plots", {})["enabled"] = False
    if a.style: o.setdefault("plots", {})["style"] = a.style
    if a.site: o.setdefault("plots", {})["focus_site"] = a.site
    if a.scenario: o.setdefault("plots", {})["focus_scenario"] = a.scenario

    res = run(a.config, o)
    print(f"\nBTEX risk assessment  |  EPC statistic: {res.cfg['input']['statistic']}")
    print(res.agg.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nOutputs written to: {res.output_dir}/  ({len(res.files)} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
