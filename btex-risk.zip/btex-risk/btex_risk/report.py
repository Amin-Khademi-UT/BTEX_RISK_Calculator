"""Create all figures and a single-file HTML report."""
from __future__ import annotations

import base64
import html
from pathlib import Path

import numpy as np
import pandas as pd

from . import montecarlo, plots


def make_all(res) -> None:
    cfg = res.cfg
    pc = cfg["plots"]
    st = plots.Style(pc["style"])
    th = cfg["thresholds"]
    out = Path(cfg["project"]["output_dir"]) / "figures"
    out.mkdir(parents=True, exist_ok=True)
    fmts, dpi, which = pc["formats"], pc["dpi"], set(pc["which"])
    comps, scs = res.compounds, res.scenarios
    site, scen = res.focus_site, res.focus_scenario
    have_mc = bool(res.mc)
    sites = list(dict.fromkeys(res.risk["site"]))
    made = {}

    def emit(name, fig):
        paths = plots.save(fig, str(out / name), fmts, dpi)
        res.files.extend(paths)
        made[name] = paths[0]

    if "dashboard" in which:
        # one dashboard per scenario for the focus site
        for s in scs:
            f = plots.fig_dashboard(res.risk, res.agg, res.mc, res.mc_summary, res.sens if s == scen else None,
                                    comps, scs, site, s, th, st, have_mc, cfg["sensitivity"]["variation"],
                                    cfg["project"]["name"])
            emit(f"dashboard_{site.replace(' ', '_')}_{s}", f)
    if "hazard" in which:
        emit("hazard_index", plots.fig_hazard(res.risk, res.agg, comps, scs, th, st))
    if "cancer" in which and any(c.iur for c in comps.values()):
        emit("cancer_risk", plots.fig_cancer(res.risk, res.agg, comps, scs, th, st))
    if "heatmap" in which:
        emit(f"heatmap_{scen}", plots.fig_heatmap(res.risk, comps, scen, scs[scen].display, th, st))
    if "contribution" in which:
        emit("contribution", plots.fig_contribution(res.risk, res.agg, comps, scs, site, th, st))
    if have_mc and "mc_distributions" in which:
        emit("mc_distributions", plots.fig_mc_distributions(res.mc, res.agg, scs, site, th, st, comps))
    if have_mc and "exceedance" in which:
        emit(f"exceedance_{scen}", plots.fig_exceedance(res.mc, scen, scs[scen].display, sites, th, st))
    if res.sens is not None and "tornado" in which:
        emit("tornado", plots.fig_tornado(res.sens, site, scs[scen].display, cfg["sensitivity"]["variation"], st))
    if have_mc and "mc_drivers" in which:
        # prefer a scenario with stochastic exposure parameters: that is where drivers differ
        dscen = next((k for k, v in scs.items() if any(p.dist != "fixed" for p in (v.ET, v.EF, v.ED))), scen)
        r = res.mc[(site, dscen)]
        emit("mc_drivers", plots.fig_mc_drivers(montecarlo.rank_drivers(r, "HI"),
                                                montecarlo.rank_drivers(r, "ELCR"), site, scs[dscen].display, st))
    if pc.get("html_report", True):
        _html(res, made, st)


def _img(path: str) -> str:
    data = base64.b64encode(Path(path).read_bytes()).decode()
    return f'<img src="data:image/png;base64,{data}" alt="">'


def _tbl(df: pd.DataFrame, floatfmt="{:.3g}") -> str:
    d = df.copy()
    return d.to_html(index=False, border=0, classes="t",
                     float_format=lambda v: floatfmt.format(v) if np.isfinite(v) else "n/a",
                     na_rep="n/a", escape=True)


def _html(res, made, st):
    cfg = res.cfg
    dark = st.name == "dark"
    bg, fg, pn, mu, gr = (st.t[k] for k in ("bg", "fg", "panel", "muted", "grid"))
    parts = [f"<h1>{html.escape(cfg['project']['name'])}</h1>",
             f"<p class='mu'>EPA RAGS Part F / RAIS inhalation methodology &nbsp;|&nbsp; EPC statistic: "
             f"<b>{cfg['input']['statistic']}</b> &nbsp;|&nbsp; focus: <b>{html.escape(res.focus_site)}</b> / "
             f"<b>{html.escape(res.focus_scenario)}</b></p>"]
    for name, p in made.items():
        parts.append(f"<h2>{html.escape(name.replace('_', ' '))}</h2><div class='card'>{_img(p)}</div>")
    parts.append("<h2>Risk summary (deterministic RME)</h2>" + _tbl(res.agg))
    parts.append("<h2>Risk by compound</h2>" + _tbl(res.risk.drop(columns=["target_organ"])))
    parts.append("<h2>Exposure-point concentrations (ug/m3)</h2>" + _tbl(res.epc.reset_index()))
    parts.append("<h2>Risk-based screening levels (ug/m3)</h2>" + _tbl(res.screening))
    if res.mc_summary is not None:
        parts.append("<h2>Monte Carlo summary</h2>" + _tbl(res.mc_summary))
    tox = pd.DataFrame([dict(compound=k, RfC_mg_m3=v.rfc, IUR_per_ugm3=v.iur, target_organ=v.target_organ,
                             source=v.source) for k, v in res.compounds.items()])
    parts.append("<h2>Toxicity values used</h2>" + _tbl(tox, "{:.3g}"))
    css = f"""body{{background:{bg};color:{fg};font-family:Inter,Segoe UI,Arial,sans-serif;max-width:1280px;margin:30px auto;padding:0 20px}}
h1{{font-size:28px}} h2{{margin-top:36px;font-size:18px;text-transform:capitalize;border-bottom:1px solid {gr};padding-bottom:6px}}
.mu{{color:{mu}}} .card{{background:{pn};border-radius:14px;padding:10px;border:1px solid {gr}}} img{{max-width:100%}}
table.t{{border-collapse:collapse;font-size:12.5px;width:100%;display:block;overflow-x:auto}}
table.t th{{background:{pn};text-align:left;padding:6px 10px;border-bottom:2px solid {gr}}}
table.t td{{padding:5px 10px;border-bottom:1px solid {gr}}}"""
    doc = f"<!doctype html><html><head><meta charset='utf-8'><title>BTEX risk report</title><style>{css}</style></head><body>{''.join(parts)}</body></html>"
    p = Path(cfg["project"]["output_dir"]) / "report.html"
    p.write_text(doc, encoding="utf-8")
    res.files.append(str(p))
