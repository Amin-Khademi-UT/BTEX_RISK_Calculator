"""Charts. Every panel is a `draw_*` function that paints onto an Axes, so the
same code serves the stand-alone figures and the one-page dashboard."""
from __future__ import annotations

from typing import Dict, Mapping, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import patheffects
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FuncFormatter, LogLocator
from scipy.stats import gaussian_kde

COMPOUND_COLORS = {
    "benzene": "#ff5d73", "toluene": "#ffb84d", "ethylbenzene": "#38d6c4", "xylenes": "#9b7bff",
}
_EXTRA = ["#6ea8ff", "#ff8fd8", "#b5e35a", "#f2a65a"]

THEMES = {
    "dark": dict(bg="#0e1320", panel="#151c2e", fg="#e9eef9", muted="#8b97b3", grid="#26304a",
                 good="#34d399", warn="#fbbf24", bad="#f43f5e", accent="#6ea8ff"),
    "light": dict(bg="#ffffff", panel="#f6f8fc", fg="#1b2333", muted="#5d6a85", grid="#dde3ef",
                  good="#16a34a", warn="#d97706", bad="#dc2626", accent="#2563eb"),
}


class Style:
    def __init__(self, name: str = "dark"):
        self.t = THEMES.get(name, THEMES["dark"])
        self.name = name
        plt.rcParams.update({
            "figure.facecolor": self.t["bg"], "savefig.facecolor": self.t["bg"],
            "axes.facecolor": self.t["panel"], "axes.edgecolor": self.t["grid"],
            "axes.labelcolor": self.t["fg"], "text.color": self.t["fg"],
            "xtick.color": self.t["muted"], "ytick.color": self.t["muted"],
            "grid.color": self.t["grid"], "grid.linewidth": 0.7,
            "axes.titleweight": "bold", "axes.titlesize": 12.5, "axes.titlecolor": self.t["fg"],
            "font.family": ["Inter", "DejaVu Sans"], "axes.spines.top": False,
            "axes.spines.right": False, "legend.frameon": False, "legend.labelcolor": self.t["fg"],
        })
        self._extra = iter(_EXTRA)
        self._colors: Dict[str, str] = dict(COMPOUND_COLORS)

    def color(self, comp: str) -> str:
        if comp not in self._colors:
            self._colors[comp] = next(self._extra, "#9aa5c0")
        return self._colors[comp]


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def fmt_val(x: float) -> str:
    if not np.isfinite(x):
        return "n/a"
    if x == 0:
        return "0"
    if 0.01 <= abs(x) < 1000:
        return f"{x:.3g}"
    return f"{x:.2e}"


def _hi_color(v, th, st: Style):
    return st.t["good"] if v < th["hq_screen"] else st.t["warn"] if v <= th["hq"] else st.t["bad"]


def _cr_color(v, th, st: Style):
    return st.t["good"] if v < th["tr_low"] else st.t["warn"] if v <= th["tr_high"] else st.t["bad"]


def _title(ax, text, sub: Optional[str] = None, st: Style = None):
    ax.set_title(text, loc="left", pad=16 if sub else 8)
    if sub:
        ax.text(0, 1.015, sub, transform=ax.transAxes, fontsize=8.5, color=st.t["muted"], va="bottom")


def _save(fig, path_base, formats, dpi):
    paths = []
    for ext in formats:
        p = f"{path_base}.{ext}"
        fig.savefig(p, dpi=dpi, bbox_inches="tight")
        paths.append(p)
    plt.close(fig)
    return paths


def _threshold_band(ax, th, st, axis="x"):
    """Shade cancer-risk bands (log axis)."""
    lo, hi = th["tr_low"], th["tr_high"]
    span = ax.axvspan if axis == "x" else ax.axhspan
    lim = ax.get_xlim() if axis == "x" else ax.get_ylim()
    span(lim[0], lo, color=st.t["good"], alpha=0.10, lw=0)
    span(lo, hi, color=st.t["warn"], alpha=0.10, lw=0)
    span(hi, max(lim[1], hi * 10), color=st.t["bad"], alpha=0.12, lw=0)
    if axis == "x":
        ax.set_xlim(lim)
    else:
        ax.set_ylim(lim)


# --------------------------------------------------------------------------
# panels
# --------------------------------------------------------------------------
def draw_hq_bars(ax, risk_g: pd.DataFrame, compounds, th, st: Style):
    """Horizontal HQ bars per compound (log x) for one site x scenario."""
    g = risk_g.dropna(subset=["HQ"]).sort_values("HQ")
    y = np.arange(len(g))
    cols = [st.color(c) for c in g["compound"]]
    ax.barh(y, g["HQ"], color=cols, height=0.62, zorder=3)
    ax.set_xscale("log")
    lo = max(min(g["HQ"].min() / 5, 1e-3), 1e-6)
    ax.set_xlim(lo, max(10, g["HQ"].max() * 4))
    ax.axvspan(th["hq"], ax.get_xlim()[1], color=st.t["bad"], alpha=0.12, lw=0)
    ax.axvline(th["hq"], color=st.t["bad"], lw=1.4, ls="--", zorder=4)
    ax.axvline(th["hq_screen"], color=st.t["warn"], lw=1.0, ls=":", zorder=4)
    for yi, (_, r) in zip(y, g.iterrows()):
        ax.text(r["HQ"] * 1.25, yi, fmt_val(r["HQ"]), va="center", fontsize=9.5, color=st.t["fg"],
                fontweight="bold")
    ax.set_yticks(y)
    ax.set_yticklabels([compounds[c].display for c in g["compound"]], fontsize=10)
    ax.grid(axis="x", zorder=0)
    ax.set_xlabel("Hazard quotient (log scale)")
    ax.text(th["hq"] * 1.08, len(g) - 0.45, "HQ = 1", color=st.t["bad"], fontsize=8, va="bottom")


def draw_cr_bars(ax, risk_g: pd.DataFrame, compounds, th, st: Style):
    g = risk_g.dropna(subset=["ELCR"]).sort_values("ELCR")
    if g.empty:
        ax.text(0.5, 0.5, "No carcinogenic compounds", ha="center", transform=ax.transAxes)
        return
    y = np.arange(len(g))
    ax.barh(y, g["ELCR"], color=[st.color(c) for c in g["compound"]], height=0.55, zorder=3)
    ax.set_xscale("log")
    ax.set_xlim(min(g["ELCR"].min() / 20, 1e-8), max(th["tr_high"] * 30, g["ELCR"].max() * 20))
    _threshold_band(ax, th, st, "x")
    ax.axvline(th["tr_low"], color=st.t["warn"], lw=1.2, ls="--", zorder=4)
    ax.axvline(th["tr_high"], color=st.t["bad"], lw=1.2, ls="--", zorder=4)
    for yi, (_, r) in zip(y, g.iterrows()):
        ax.text(r["ELCR"] * 1.5, yi, fmt_val(r["ELCR"]), va="center", fontsize=9.5,
                fontweight="bold", color=st.t["fg"])
    ax.set_yticks(y)
    ax.set_yticklabels([compounds[c].display for c in g["compound"]], fontsize=10)
    ax.grid(axis="x", zorder=0)
    ax.set_xlabel("Excess lifetime cancer risk (log scale)")


def draw_donut(ax, values: Mapping[str, float], compounds, st: Style, center_title: str, center_value: str):
    items = {k: v for k, v in values.items() if np.isfinite(v) and v > 0}
    if not items:
        ax.axis("off")
        ax.text(0.5, 0.5, "n/a", ha="center", transform=ax.transAxes)
        return
    keys = list(items)
    wedges, _ = ax.pie([items[k] for k in keys], colors=[st.color(k) for k in keys], startangle=90,
                       counterclock=False, wedgeprops=dict(width=0.36, edgecolor=st.t["panel"], linewidth=2))
    tot = sum(items.values())
    ax.text(0, 0.08, center_value, ha="center", va="center", fontsize=15, fontweight="bold")
    ax.text(0, -0.17, center_title, ha="center", va="center", fontsize=8.5, color=st.t["muted"])
    for w, k in zip(wedges, keys):
        pct = 100 * items[k] / tot
        if pct >= 6:
            ang = np.deg2rad((w.theta2 + w.theta1) / 2)
            ax.text(0.82 * np.cos(ang), 0.82 * np.sin(ang), f"{pct:.0f}%", ha="center", va="center",
                    fontsize=8.5, fontweight="bold", color="#0e1320")
    ax.legend(wedges, [compounds[k].display for k in keys], loc="upper center",
              bbox_to_anchor=(0.5, 0.02), ncol=2, fontsize=8.5, handlelength=1, columnspacing=1)
    ax.set_aspect("equal")


def _kde_log(ax, x, color, st, label=None, lw=2.2):
    x = np.asarray(x)
    x = x[x > 0]
    lx = np.log10(x)
    grid = np.linspace(lx.min() - 0.3, lx.max() + 0.3, 400)
    try:
        d = gaussian_kde(lx)(grid)
    except Exception:  # degenerate
        d = np.zeros_like(grid)
    ax.fill_between(10 ** grid, d, color=color, alpha=0.22, lw=0)
    ax.plot(10 ** grid, d, color=color, lw=lw, label=label)
    return grid, d


def draw_mc_hist(ax, samples: np.ndarray, color, th_lines: Mapping[str, tuple], st: Style, xlabel: str,
                 prob_text: Optional[str] = None):
    """Smoothed density on a log-x axis with percentile markers and thresholds."""
    x = np.asarray(samples)
    x = x[x > 0]
    lx = np.log10(x)
    counts, edges = np.histogram(lx, bins=70, density=True)
    ax.bar(10 ** edges[:-1], counts, width=np.diff(10 ** edges), align="edge", color=color, alpha=0.30, zorder=2)
    ax.set_xscale("log")
    _kde_log(ax, x, color, st)
    p50, p95 = np.percentile(x, [50, 95])
    lo, hi = np.percentile(x, [0.2, 99.8])
    xmin, xmax = lo / 1.6, hi * 1.6
    outside = {}
    for label, (xv, col) in th_lines.items():
        if xmin / 8 < xv < xmax * 8:          # near the data: widen the view to include it
            xmin, xmax = min(xmin, xv / 1.3), max(xmax, xv * 1.3)
        else:
            outside[label] = (xv, col)
    ax.set_xlim(xmin, xmax)
    ymax = ax.get_ylim()[1]
    ax.set_ylim(0, ymax * 1.08)
    ax.axvline(p50, color=st.t["fg"], lw=1.3, zorder=4)
    ax.axvline(p95, color=st.t["fg"], lw=1.3, ls="--", zorder=4)
    ax.text(p50, ymax * 1.02, f"P50 {fmt_val(p50)} ", fontsize=8.5, va="top", ha="right", color=st.t["fg"])
    ax.text(p95, ymax * 0.90, f" P95 {fmt_val(p95)}", fontsize=8.5, va="top", ha="left", color=st.t["fg"])
    for i, (label, (xv, col)) in enumerate(th_lines.items()):
        if label in outside:
            side = 0.0 if xv < xmin else 1.0
            arrow = "\u25c0" if xv < xmin else "\u25b6"
            txt = f"{arrow} {label} (off scale)" if xv < xmin else f"{label} (off scale) {arrow}"
            ax.text(side, 0.04 + 0.07 * i, txt, transform=ax.transAxes, ha="left" if side == 0 else "right",
                    fontsize=8.5, color=col)
        else:
            ax.axvline(xv, color=col, lw=1.7, ls=":", zorder=4)
            ax.text(xv, ymax * 0.50, f" {label} ", color=col, fontsize=8.5, rotation=90, va="top",
                    ha="right" if xv > p50 else "left")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Density")
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    if prob_text:
        ax.set_title(prob_text.replace("\n", "   "), loc="right", fontsize=9, color=st.t["muted"], fontweight="normal")


def draw_tornado(ax, sens: pd.DataFrame, metric: str, st: Style, color_lo, color_hi):
    on = sens[sens[f"on_{metric}"]].copy()
    base = float(on[f"base_{metric}"].iloc[0])
    on["swing"] = (on[f"{metric}_high"] - on[f"{metric}_low"]).abs()
    on = on.sort_values("swing")
    y = np.arange(len(on))
    for yi, (_, r) in zip(y, on.iterrows()):
        lo, hi = r[f"{metric}_low"], r[f"{metric}_high"]
        a, b = sorted([lo, hi])
        ax.barh(yi, base - a, left=a, color=color_lo, height=0.6, zorder=3)
        ax.barh(yi, b - base, left=base, color=color_hi, height=0.6, zorder=3)
        if r["swing"] < 1e-15:
            ax.text(base, yi, "  no effect (ED cancels: AT = ED)", va="center", fontsize=8, color=st.t["muted"])
    ax.axvline(base, color=st.t["fg"], lw=1.2, zorder=4)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{p}\n[{r}]" for p, r in zip(on["parameter"], on["range"])], fontsize=8.5,
                       linespacing=1.1)
    ax.grid(axis="x", zorder=0)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: fmt_val(v)))
    ax.set_xlabel("Hazard index" if metric == "HI" else "Excess lifetime cancer risk")
    ax.margins(x=0.08)


# --------------------------------------------------------------------------
# stand-alone figures
# --------------------------------------------------------------------------
def fig_hazard(risk, agg, compounds, scenarios, th, st: Style):
    scs = list(scenarios)
    fig, axes = plt.subplots(1, len(scs), figsize=(6.3 * len(scs), 5.6), sharey=True, squeeze=False)
    sites = list(dict.fromkeys(risk["site"]))
    stacks = {}
    for s in scs:
        d = risk[risk["scenario"] == s]
        stacks[s] = {comp: np.array([d[(d.site == site) & (d.compound == comp)]["HQ"].sum() for site in sites])
                     for comp in compounds}
    tops = [sum(v for v in stacks[s].values()).max() for s in scs]
    ymax = max(1.35, max(tops) * 1.18)
    for ax, s in zip(axes[0], scs):
        bottoms = np.zeros(len(sites))
        for comp, vals in stacks[s].items():
            if vals.sum() == 0:
                continue
            ax.bar(sites, vals, bottom=bottoms, color=st.color(comp), width=0.62, zorder=3)
            bottoms += vals
        ax.set_ylim(0, ymax)
        ax.axhspan(th["hq"], ymax, color=st.t["bad"], alpha=0.12, lw=0)
        ax.axhline(th["hq"], color=st.t["bad"], ls="--", lw=1.4, zorder=4)
        ax.axhline(th["hq_screen"], color=st.t["warn"], ls=":", lw=1.1, zorder=4)
        for x, v in enumerate(bottoms):
            ax.text(x, v + ymax * 0.012, fmt_val(v), ha="center", fontsize=10, fontweight="bold",
                    color=_hi_color(v, th, st))
        ax.set_title(scenarios[s].display, loc="left")
        ax.grid(axis="y", zorder=0)
        ax.tick_params(axis="x", rotation=25)
        plt.setp(ax.get_xticklabels(), ha="right")
    axes[0][0].set_ylabel("Hazard index (sum of HQ)")
    handles = [plt.Rectangle((0, 0), 1, 1, color=st.color(c)) for c in compounds]
    fig.legend(handles, [compounds[c].display for c in compounds], ncol=len(compounds), fontsize=10,
               loc="upper right", bbox_to_anchor=(0.995, 1.04))
    fig.suptitle("Non-cancer hazard index by site (stacked by compound)", x=0.01, ha="left",
                 fontsize=15, fontweight="bold", y=1.04)
    fig.tight_layout()
    return fig


def fig_cancer(risk, agg, compounds, scenarios, th, st: Style):
    scs = list(scenarios)
    fig, axes = plt.subplots(1, len(scs), figsize=(6.3 * len(scs), 5.6), sharey=True, squeeze=False)
    sites = list(dict.fromkeys(risk["site"]))
    carc = [c for c in compounds if compounds[c].iur]
    for ax, s in zip(axes[0], scs):
        d = risk[risk["scenario"] == s]
        w = 0.8 / (len(carc) + 1)
        x0 = np.arange(len(sites))
        for i, comp in enumerate(carc):
            vals = np.array([d[(d.site == site) & (d.compound == comp)]["ELCR"].sum() for site in sites])
            ax.bar(x0 + (i - len(carc) / 2) * w + w / 2, vals, width=w * 0.92, color=st.color(comp),
                   zorder=3)
        tot = np.array([agg[(agg.site == site) & (agg.scenario == s)]["ELCR"].iloc[0] for site in sites])
        ax.bar(x0 + (len(carc) / 2) * w + w / 2, tot, width=w * 0.92, color=st.t["fg"], alpha=0.85,
               zorder=3)
        ax.set_yscale("log")
        ax.set_ylim(min(1e-8, np.nanmin(tot[tot > 0]) / 10 if (tot > 0).any() else 1e-8), max(1e-3, tot.max() * 10))
        _threshold_band(ax, th, st, "y")
        ax.axhline(th["tr_low"], color=st.t["warn"], ls="--", lw=1.2, zorder=4)
        ax.axhline(th["tr_high"], color=st.t["bad"], ls="--", lw=1.2, zorder=4)
        for x, v in zip(x0 + (len(carc) / 2) * w + w / 2, tot):
            ax.text(x, v * 1.35, fmt_val(v), ha="center", fontsize=8.5, fontweight="bold",
                    color=_cr_color(v, th, st), rotation=0)
        ax.set_xticks(x0)
        ax.set_xticklabels(sites, rotation=25, ha="right")
        ax.set_title(scenarios[s].display, loc="left")
        ax.grid(axis="y", zorder=0)
    axes[0][0].set_ylabel("Excess lifetime cancer risk (log scale)")
    handles = [plt.Rectangle((0, 0), 1, 1, color=st.color(c)) for c in carc] + \
              [plt.Rectangle((0, 0), 1, 1, color=st.t["fg"], alpha=0.85)]
    fig.legend(handles, [compounds[c].display for c in carc] + ["Total"], ncol=len(carc) + 1, fontsize=10,
               loc="upper right", bbox_to_anchor=(0.995, 1.04))
    fig.suptitle("Carcinogenic risk by site  |  green < 1e-6 < amber (EPA range) < 1e-4 < red",
                 x=0.01, ha="left", fontsize=14, fontweight="bold", y=1.04)
    fig.tight_layout()
    return fig


def fig_heatmap(risk, compounds, scenario, scen_label, th, st: Style):
    d = risk[risk["scenario"] == scenario]
    sites = list(dict.fromkeys(d["site"]))
    comps = list(compounds)
    hq = np.array([[d[(d.site == s) & (d.compound == c)]["HQ"].sum() if c in d.compound.values else np.nan
                    for c in comps] for s in sites])
    cr_m = np.array([[d[(d.site == s) & (d.compound == c)]["ELCR"].sum(min_count=1) for c in comps] for s in sites])
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.5, 0.75 * len(sites) + 3.4), layout="constrained")
    for ax, M, title, cmap, vmin, vmax, f in (
        (a1, hq, "Hazard quotient", "YlOrRd", 1e-3, 3, lambda v: fmt_val(v)),
        (a2, cr_m, "Excess lifetime cancer risk", "YlOrRd", 1e-8, 1e-3, lambda v: fmt_val(v)),
    ):
        from matplotlib.colors import LogNorm
        Mm = np.ma.masked_invalid(np.where(np.asarray(M, float) > 0, M, np.nan))
        im = ax.imshow(Mm, aspect="auto", cmap=cmap, norm=LogNorm(vmin=vmin, vmax=vmax))
        ax.set_xticks(range(len(comps)))
        ax.set_xticklabels([compounds[c].display for c in comps], fontsize=10)
        ax.set_yticks(range(len(sites)))
        ax.set_yticklabels(sites, fontsize=10)
        ax.xaxis.tick_top()
        for i in range(len(sites)):
            for j in range(len(comps)):
                v = M[i, j]
                if np.isfinite(v) and v > 0:
                    rgba = im.cmap(im.norm(v))
                    lum = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
                    ax.text(j, i, f(v), ha="center", va="center", fontsize=9.5, fontweight="bold",
                            color="#101522" if lum > 0.55 else "#ffffff")
                else:
                    ax.text(j, i, "n/a", ha="center", va="center", fontsize=8.5, color=st.t["muted"])
        ax.set_title(title, loc="left", pad=28)
        for sp in ax.spines.values():
            sp.set_visible(False)
        ax.set_xticks(np.arange(-.5, len(comps), 1), minor=True)
        ax.set_yticks(np.arange(-.5, len(sites), 1), minor=True)
        ax.grid(which="minor", color=st.t["bg"], lw=3)
        ax.tick_params(which="both", length=0)
        cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.03)
        cb.outline.set_visible(False)
    fig.suptitle(f"Risk heat-map  |  {scen_label}", x=0.01, ha="left", fontsize=15, fontweight="bold")
    return fig


def fig_contribution(risk, agg, compounds, scenarios, site, th, st: Style):
    scs = list(scenarios)
    fig, axes = plt.subplots(2, len(scs), figsize=(4.6 * len(scs), 8), squeeze=False)
    for j, s in enumerate(scs):
        g = risk[(risk.site == site) & (risk.scenario == s)]
        a = agg[(agg.site == site) & (agg.scenario == s)].iloc[0]
        draw_donut(axes[0][j], dict(zip(g.compound, g.HQ.fillna(0))), compounds, st, "Hazard index",
                   fmt_val(a["HI"]))
        axes[0][j].set_title(scenarios[s].display, fontsize=11)
        draw_donut(axes[1][j], dict(zip(g.compound, g.ELCR.fillna(0))), compounds, st, "Cancer risk",
                   fmt_val(a["ELCR"]))
    fig.suptitle(f"Contribution of each compound  |  {site}", x=0.01, ha="left", fontsize=15,
                 fontweight="bold", y=1.0)
    fig.tight_layout()
    return fig


def fig_mc_distributions(mc, agg, scenarios, site, th, st: Style, compounds):
    scs = list(scenarios)
    fig, axes = plt.subplots(2, len(scs), figsize=(6.0 * len(scs), 7.6), squeeze=False)
    for j, s in enumerate(scs):
        r = mc[(site, s)]
        pt = f"P(HI > 1) = {100 * (r.HI > th['hq']).mean():.2f}%"
        draw_mc_hist(axes[0][j], r.HI, st.t["accent"], {"HQ = 1": (th["hq"], st.t["bad"])}, st,
                     "Hazard index", pt)
        axes[0][j].set_title(scenarios[s].display, loc="left")
        pe = (f"P(>1e-6) = {100 * (r.ELCR > th['tr_low']).mean():.1f}%\n"
              f"P(>1e-4) = {100 * (r.ELCR > th['tr_high']).mean():.2f}%")
        if np.any(r.ELCR > 0):
            draw_mc_hist(axes[1][j], r.ELCR, st.color("benzene"),
                         {"1e-6": (th["tr_low"], st.t["warn"]), "1e-4": (th["tr_high"], st.t["bad"])}, st,
                         "Excess lifetime cancer risk", pe)
    fig.suptitle(f"Monte Carlo distributions  |  {site}  ({len(next(iter(mc.values())).HI):,} iterations)",
                 x=0.01, ha="left", fontsize=15, fontweight="bold", y=1.0)
    fig.tight_layout()
    return fig


def fig_exceedance(mc, scenario, scen_label, sites, th, st: Style):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.5, 5.6))
    pal = plt.cm.cool(np.linspace(0.05, 0.95, len(sites)))
    for site, col in zip(sites, pal):
        r = mc[(site, scenario)]
        for ax, arr in ((a1, r.HI), (a2, r.ELCR)):
            x = np.sort(arr[arr > 0])
            if x.size == 0:
                continue
            p = 1 - (np.arange(1, x.size + 1) / x.size)
            ax.plot(x, p + 1e-6, lw=2.3, color=col, label=site)
    for ax, xl, lines in ((a1, "Hazard index", [(th["hq"], st.t["bad"], "HQ = 1")]),
                          (a2, "Excess lifetime cancer risk",
                           [(th["tr_low"], st.t["warn"], "1e-6"), (th["tr_high"], st.t["bad"], "1e-4")])):
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_ylim(1e-4, 1.2)
        ax.set_xlabel(xl)
        ax.set_ylabel("Probability of exceeding the value")
        for xv, c, lab in lines:
            ax.axvline(xv, color=c, ls="--", lw=1.4)
            ax.text(xv, 1.1, f" {lab}", color=c, fontsize=9, va="bottom")
        ax.grid(True, which="major")
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{100 * v:g}%"))
    a1.legend(fontsize=9, loc="lower left")
    fig.suptitle(f"Exceedance curves  |  {scen_label}", x=0.01, ha="left", fontsize=15, fontweight="bold", y=1.02)
    fig.tight_layout()
    return fig


def fig_tornado(sens, site, scen_label, variation, st: Style):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(14, 5.4))
    draw_tornado(a1, sens, "HI", st, "#4dc9f6", "#f67019")
    a1.set_title("Hazard index", loc="left")
    draw_tornado(a2, sens, "ELCR", st, "#4dc9f6", "#f67019")
    a2.set_title("Cancer risk", loc="left")
    fig.suptitle(f"One-at-a-time sensitivity (plausible low\u2013high ranges)  |  {site}  |  {scen_label}",
                 x=0.01, ha="left", fontsize=15, fontweight="bold", y=1.02)
    fig.tight_layout()
    return fig


def fig_mc_drivers(drivers_hi: pd.Series, drivers_cr: pd.Series, site, scen_label, st: Style):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5.0))
    for ax, ser, title in ((a1, drivers_hi, "Hazard index"), (a2, drivers_cr, "Cancer risk")):
        ser = ser.iloc[:8][::-1]
        cols = [st.t["accent"] if v >= 0 else st.t["bad"] for v in ser.values]
        ax.barh(ser.index, ser.values, color=cols, height=0.6, zorder=3)
        ax.axvline(0, color=st.t["fg"], lw=1)
        ax.set_xlim(min(-0.1, ser.min() - 0.15), 1.05)
        ax.set_title(title, loc="left")
        ax.set_xlabel("Spearman rank correlation")
        ax.grid(axis="x", zorder=0)
        for y, v in enumerate(ser.values):
            ax.text(v + (0.03 if v >= 0 else -0.03), y, f"{v:.2f}", va="center",
                    ha="left" if v >= 0 else "right", fontsize=9)
    fig.suptitle(f"What drives the uncertainty? (Monte Carlo)  |  {site}  |  {scen_label}", x=0.01,
                 ha="left", fontsize=15, fontweight="bold", y=1.02)
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------
# dashboard
# --------------------------------------------------------------------------
def _kpi(ax, title, value, sub, color, st: Style):
    ax.axis("off")
    ax.add_patch(FancyBboxPatch((0.0, 0.0), 1, 1, boxstyle="round,pad=0,rounding_size=0.08",
                                transform=ax.transAxes, fc=st.t["panel"], ec=color, lw=2))
    ax.text(0.06, 0.82, title.upper(), transform=ax.transAxes, fontsize=9, color=st.t["muted"], va="center",
            fontweight="bold")
    ax.text(0.06, 0.47, value, transform=ax.transAxes, fontsize=24, fontweight="bold", color=color, va="center")
    ax.text(0.06, 0.14, sub, transform=ax.transAxes, fontsize=8.5, color=st.t["muted"], va="center")


def fig_dashboard(risk, agg, mc, mcsum, sens, compounds, scenarios, site, scen, th, st: Style, mc_enabled, variation,
                  project_name=""):
    sc = scenarios[scen]
    g = risk[(risk.site == site) & (risk.scenario == scen)]
    a = agg[(agg.site == site) & (agg.scenario == scen)].iloc[0]
    fig = plt.figure(figsize=(18.5, 11.6))
    gs = GridSpec(3, 3, figure=fig, height_ratios=[0.42, 1, 1], hspace=0.62, wspace=0.28,
                  left=0.045, right=0.985, top=0.885, bottom=0.07)
    # header
    fig.text(0.045, 0.955, project_name or "BTEX inhalation health risk", fontsize=22, fontweight="bold")
    fig.text(0.045, 0.918, f"Site: {site}   \u2022   Receptor: {sc.display}   \u2022   "
             f"ET {sc.ET.value:g} h/d, EF {sc.EF.value:g} d/y, ED {sc.ED.value:g} y, LT {sc.LT:g} y   \u2022   "
             "EPA RAGS Part F / RAIS", fontsize=10.5, color=st.t["muted"])
    # KPI cards
    sub = gs[0, :].subgridspec(1, 4, wspace=0.12)
    _kpi(fig.add_subplot(sub[0]), "Hazard index (RME)", fmt_val(a["HI"]),
         f"driver: {compounds[a['HQ_driver']].display if a['HQ_driver'] else 'n/a'}",
         _hi_color(a["HI"], th, st), st)
    _kpi(fig.add_subplot(sub[1]), "Cancer risk (RME)", fmt_val(a["ELCR"]),
         f"driver: {compounds[a['ELCR_driver']].display if a['ELCR_driver'] else 'n/a'}",
         _cr_color(a["ELCR"], th, st), st)
    if mc_enabled and (site, scen) in mc:
        r = mc[(site, scen)]
        _kpi(fig.add_subplot(sub[2]), "HI  P95 (Monte Carlo)", fmt_val(np.percentile(r.HI, 95)),
             f"P(HI>1) = {100 * (r.HI > th['hq']).mean():.2f}%", _hi_color(np.percentile(r.HI, 95), th, st), st)
        _kpi(fig.add_subplot(sub[3]), "Cancer risk P95 (MC)", fmt_val(np.percentile(r.ELCR, 95)),
             f"P(>1e-6) = {100 * (r.ELCR > th['tr_low']).mean():.1f}%",
             _cr_color(np.percentile(r.ELCR, 95), th, st), st)
    else:
        for k in (2, 3):
            _kpi(fig.add_subplot(sub[k]), "Monte Carlo", "off", "enable in config", st.t["muted"], st)

    # row 1
    ax = fig.add_subplot(gs[1, 0]); draw_hq_bars(ax, g, compounds, th, st)
    _title(ax, "Hazard quotient by compound", "RAIS shading: HQ > 0.1 / HQ > 1", st)
    ax = fig.add_subplot(gs[1, 1]); draw_cr_bars(ax, g, compounds, th, st)
    _title(ax, "Cancer risk by compound", "EPA target range 1e-6 \u2013 1e-4", st)
    ax = fig.add_subplot(gs[1, 2])
    draw_donut(ax, dict(zip(g.compound, g.HQ.fillna(0))), compounds, st, "Hazard index", fmt_val(a["HI"]))
    _title(ax, "Share of hazard index", None, st)
    # row 2
    if mc_enabled and (site, scen) in mc:
        r = mc[(site, scen)]
        ax = fig.add_subplot(gs[2, 0])
        draw_mc_hist(ax, r.HI, st.t["accent"], {"HQ = 1": (th["hq"], st.t["bad"])}, st, "Hazard index")
        _title(ax, "Monte Carlo: hazard index", f"{len(r.HI):,} iterations", st)
        ax = fig.add_subplot(gs[2, 1])
        if np.any(r.ELCR > 0):
            draw_mc_hist(ax, r.ELCR, st.color("benzene"),
                         {"1e-6": (th["tr_low"], st.t["warn"]), "1e-4": (th["tr_high"], st.t["bad"])}, st,
                         "Excess lifetime cancer risk")
        _title(ax, "Monte Carlo: cancer risk", "solid = P50, dashed = P95", st)
    else:
        for k in (0, 1):
            ax = fig.add_subplot(gs[2, k]); ax.axis("off")
            ax.text(0.5, 0.5, "Monte Carlo disabled", ha="center", transform=ax.transAxes, color=st.t["muted"])
    ax = fig.add_subplot(gs[2, 2])
    if sens is not None:
        draw_tornado(ax, sens, "ELCR", st, "#4dc9f6", "#f67019")
        _title(ax, "Cancer-risk sensitivity", "one-at-a-time, plausible low\u2013high ranges", st)
    else:
        ax.axis("off")
    fig.text(0.985, 0.012, "btex-risk  \u2022  generated with RAGS Part F / RAIS equations", ha="right",
             fontsize=8.5, color=st.t["muted"])
    return fig


def save(fig, base, formats, dpi):
    return _save(fig, base, formats, dpi)
