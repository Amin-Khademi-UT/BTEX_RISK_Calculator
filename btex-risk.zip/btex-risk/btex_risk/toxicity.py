"""Chronic inhalation toxicity values and compound metadata.

Defaults follow the hierarchy used by RAIS / EPA Regional Screening Levels
(RSL): chronic RfC and inhalation unit risk (IUR) from EPA IRIS, with
CalEPA (OEHHA) for the ethylbenzene IUR.

    compound       RfC (mg/m3)   IUR (ug/m3)^-1   source
    benzene        0.03          7.8e-6           IRIS
    toluene        5             --               IRIS
    ethylbenzene   1             2.5e-6           IRIS (RfC) / CalEPA (IUR)
    xylenes        0.1           --               IRIS

Toxicity values are revised from time to time. Always confirm them against
the current RAIS / RSL tables (https://rais.ornl.gov) and override them in the
YAML config (``toxicity.compounds``) when needed -- nothing is hard-wired.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Dict, Optional

import re


@dataclass(frozen=True)
class Compound:
    name: str
    mw: float                          # g/mol, for ppb/ppm -> ug/m3
    rfc: Optional[float]               # mg/m3, chronic inhalation RfC (None = not available)
    iur: Optional[float]               # (ug/m3)^-1, inhalation unit risk (None = non-carcinogen)
    target_organ: str = "unspecified"  # critical-effect group for target-organ HI
    cas: str = ""
    label: str = ""
    source: str = ""

    @property
    def display(self) -> str:
        return self.label or self.name.capitalize()


DEFAULT_COMPOUNDS: Dict[str, Compound] = {
    "benzene": Compound(
        "benzene", 78.11, 0.03, 7.8e-6, "hematological / immune", "71-43-2",
        "Benzene", "IRIS (RfC, IUR)"),
    "toluene": Compound(
        "toluene", 92.14, 5.0, None, "neurological", "108-88-3",
        "Toluene", "IRIS (RfC)"),
    "ethylbenzene": Compound(
        "ethylbenzene", 106.17, 1.0, 2.5e-6, "developmental", "100-41-4",
        "Ethylbenzene", "IRIS (RfC); CalEPA (IUR)"),
    "xylenes": Compound(
        "xylenes", 106.17, 0.1, None, "neurological", "1330-20-7",
        "Xylenes", "IRIS (RfC)"),
}

# Names that show up in lab reports -> canonical key.
ALIASES = {
    "benzene": "benzene",
    "toluene": "toluene", "methylbenzene": "toluene",
    "ethylbenzene": "ethylbenzene", "ethyl benzene": "ethylbenzene", "eb": "ethylbenzene",
    "xylene": "xylenes", "xylenes": "xylenes", "total xylenes": "xylenes",
    "m,p-xylene": "xylenes", "m-xylene": "xylenes", "p-xylene": "xylenes",
    "o-xylene": "xylenes", "mp-xylene": "xylenes", "m/p-xylene": "xylenes",
}


def _norm(name: str) -> str:
    return re.sub(r"\s+", " ", str(name).strip().lower())


def canonical_name(name: str, known: Dict[str, Compound]) -> str:
    key = _norm(name)
    if key in known:
        return key
    if key in ALIASES and ALIASES[key] in known:
        return ALIASES[key]
    raise KeyError(
        f"Unknown compound '{name}'. Known: {sorted(known)}. "
        "Add it under `toxicity.compounds` in your config (mw, rfc, iur)."
    )


def build_compounds(toxicity_cfg: dict) -> Dict[str, Compound]:
    """Merge the default table with user overrides / additional compounds."""
    out = dict(DEFAULT_COMPOUNDS)
    user = (toxicity_cfg or {}).get("compounds") or {}
    for raw_name, spec in user.items():
        key = _norm(raw_name)
        spec = dict(spec or {})
        if key in out:
            base = out[key]
            kwargs = {}
            for field in ("mw", "rfc", "iur", "target_organ", "cas", "label", "source"):
                if field in spec:
                    kwargs[field] = spec[field]
            out[key] = replace(base, **kwargs)
        else:
            if "mw" not in spec:
                raise ValueError(f"New compound '{raw_name}' needs at least `mw` (g/mol).")
            out[key] = Compound(
                name=key,
                mw=float(spec["mw"]),
                rfc=spec.get("rfc"),
                iur=spec.get("iur"),
                target_organ=spec.get("target_organ", "unspecified"),
                cas=spec.get("cas", ""),
                label=spec.get("label", key.capitalize()),
                source=spec.get("source", "user-defined"),
            )
    return out
