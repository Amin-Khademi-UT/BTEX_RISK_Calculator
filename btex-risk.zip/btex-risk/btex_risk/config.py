"""Configuration: defaults + YAML overrides (every key is optional)."""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Mapping, Optional

import yaml

DEFAULTS: dict = {
    "project": {
        "name": "BTEX inhalation health risk assessment",
        "output_dir": "results",
    },
    "input": {
        "concentrations_csv": "data/example_synthetic_btex.csv",
        # EPC statistic fed to the deterministic (RME) calculation:
        #   ucl95 | mean | median | p95 | max
        "statistic": "ucl95",
        "default_unit": "ug/m3",      # used when the CSV has no `unit` column
        "nondetect_factor": 0.5,      # non-detect -> factor * detection limit
        "temperature_c": 25.0,        # for ppb/ppm -> ug/m3
        "pressure_kpa": 101.325,
        "sites": None,                # optional list to keep only some sites
    },
    "life_time_years": 70,
    "scenarios": {
        "resident": {"preset": "resident"},
        "worker": {"preset": "worker"},
    },
    "thresholds": {
        "hq": 1.0,                    # HI/HQ level of concern
        "hq_screen": 0.1,             # RAIS shading threshold
        "tr_low": 1.0e-6,             # lower bound of the EPA target risk range
        "tr_high": 1.0e-4,            # upper bound of the EPA target risk range
    },
    "toxicity": {"compounds": {}},
    "monte_carlo": {
        "enabled": True,
        "n_iter": 10000,
        "seed": 42,
        "concentration": {
            # mean_uncertainty : sample the uncertainty of the long-term mean
            #                    (appropriate for chronic exposure; default)
            # measurements     : sample the spread of individual measurements
            "mode": "mean_uncertainty",
            "default_gsd": 1.8,       # used when a site/compound has < 3 samples
            "correlation": 0.0,       # rank correlation between compounds (0..1)
        },
    },
    "sensitivity": {
        "enabled": True,
        "variation": 0.20,            # +/- fraction for one-at-a-time analysis
        "ranges": None,               # optional absolute ranges, e.g. {ET: [6, 12], EF: [250, 350]}
    },
    "plots": {
        "enabled": True,
        "style": "dark",              # dark | light
        "dpi": 200,
        "formats": ["png"],
        "focus_site": None,           # default: site with highest cancer risk
        "focus_scenario": None,       # default: first scenario
        "html_report": True,
        "which": ["dashboard", "hazard", "cancer", "heatmap", "contribution",
                  "mc_distributions", "exceedance", "tornado", "mc_drivers"],
    },
}


def deep_merge(base: dict, over: Mapping) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, Mapping) and isinstance(out.get(k), dict) and k not in ("scenarios",):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path: Optional[str] = None, overrides: Optional[Mapping] = None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    cfg["_config_dir"] = str(Path.cwd())
    if path:
        p = Path(path)
        with open(p, "r", encoding="utf-8") as fh:
            user = yaml.safe_load(fh) or {}
        cfg = deep_merge(cfg, user)
        cfg["_config_dir"] = str(p.resolve().parent)
    if overrides:
        cfg = deep_merge(cfg, overrides)
    return cfg


def resolve_path(cfg: Mapping, p: str) -> Path:
    """Resolve a path relative to CWD first, then to the config file's folder
    (and its parent, so `configs/x.yaml` can point at `data/y.csv`)."""
    path = Path(p)
    if path.is_absolute() and path.exists():
        return path
    for base in (Path.cwd(), Path(cfg["_config_dir"]), Path(cfg["_config_dir"]).parent):
        cand = base / path
        if cand.exists():
            return cand
    raise FileNotFoundError(f"Cannot find '{p}' (looked in CWD and next to the config file).")
