"""Monte Carlo propagation of exposure-parameter and concentration uncertainty.

Every iteration draws ONE set of ET / EF / ED values (shared by all compounds,
because they describe the same person) and one concentration per compound.
Compounds can be rank-correlated through a Gaussian copula.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping

import numpy as np
import pandas as pd

from .exposure import HOURS_PER_YEAR, Scenario


@dataclass
class MCResult:
    site: str
    scenario: str
    HI: np.ndarray
    ELCR: np.ndarray
    HQ: Dict[str, np.ndarray]
    CR: Dict[str, np.ndarray]
    inputs: Dict[str, np.ndarray]     # sampled drivers, for rank-correlation


def _lognormal_for_mean(mean: float, cv: float):
    """(mu, sigma) of ln X for a lognormal with the given arithmetic mean / CV."""
    s2 = np.log1p(cv ** 2)
    return np.log(mean) - 0.5 * s2, np.sqrt(s2)


def _conc_params(rec: pd.Series, mc_cfg: Mapping):
    """Return (mu_ln, sigma_ln) of the sampled concentration distribution."""
    ccfg = mc_cfg["concentration"]
    mean = max(float(rec["mean"]), 1e-12)
    n = int(rec["n"])
    have_sd = n >= 3 and np.isfinite(rec["sdlog"])
    sdlog = float(rec["sdlog"]) if have_sd else np.log(float(ccfg["default_gsd"]))
    cv = float(np.sqrt(np.expm1(sdlog ** 2)))
    if ccfg["mode"] == "measurements":
        return _lognormal_for_mean(mean, cv)
    if ccfg["mode"] == "mean_uncertainty":
        n_eff = n if have_sd else 1
        return _lognormal_for_mean(mean, cv / np.sqrt(n_eff))
    raise ValueError("monte_carlo.concentration.mode must be 'mean_uncertainty' or 'measurements'")


def simulate(site: str, epc_site: pd.DataFrame, scen: Scenario, compounds, mc_cfg: Mapping,
             rng: np.random.Generator) -> MCResult:
    n = int(mc_cfg["n_iter"])
    ET, EF, ED = scen.ET.sample(n, rng), scen.EF.sample(n, rng), scen.ED.sample(n, rng)
    at_nc = ED * HOURS_PER_YEAR
    at_c = scen.LT * HOURS_PER_YEAR
    f_nc = ET * EF * ED / at_nc
    f_c = ET * EF * ED / at_c

    rho = float(np.clip(mc_cfg["concentration"]["correlation"], 0.0, 0.999))
    z0 = rng.standard_normal(n)

    HQ, CR, inputs = {}, {}, {"ET": ET, "EF": EF, "ED": ED}
    hi = np.zeros(n)
    elcr = np.zeros(n)
    for comp, rec in epc_site.iterrows():
        c = compounds[comp]
        mu, sig = _conc_params(rec, mc_cfg)
        z = np.sqrt(rho) * z0 + np.sqrt(1 - rho) * rng.standard_normal(n)
        ca = np.exp(mu + sig * z)
        inputs[f"CA {c.display}"] = ca
        if c.rfc:
            HQ[comp] = ca * f_nc / (c.rfc * 1000.0)
            hi += HQ[comp]
        if c.iur:
            CR[comp] = ca * f_c * c.iur
            elcr += CR[comp]
    return MCResult(site, scen.name, hi, elcr, HQ, CR, inputs)


def run_monte_carlo(epc: pd.DataFrame, scenarios: Mapping[str, Scenario], compounds,
                    mc_cfg: Mapping) -> Dict[tuple, MCResult]:
    ss = np.random.SeedSequence(int(mc_cfg["seed"]))
    keys = [(site, sname) for site in epc.index.get_level_values(0).unique() for sname in scenarios]
    children = ss.spawn(len(keys))
    out = {}
    for (site, sname), child in zip(keys, children):
        rng = np.random.default_rng(child)
        out[(site, sname)] = simulate(site, epc.loc[site], scenarios[sname], compounds, mc_cfg, rng)
    return out


def summarize(mc: Mapping[tuple, MCResult], thresholds: Mapping) -> pd.DataFrame:
    rows = []
    for (site, sname), r in mc.items():
        def q(a, p):
            return float(np.percentile(a, p))
        rows.append(dict(
            site=site, scenario=sname,
            HI_mean=float(r.HI.mean()), HI_p5=q(r.HI, 5), HI_p50=q(r.HI, 50),
            HI_p95=q(r.HI, 95), HI_p99=q(r.HI, 99),
            P_HI_gt_1=float((r.HI > thresholds["hq"]).mean()),
            ELCR_mean=float(r.ELCR.mean()), ELCR_p5=q(r.ELCR, 5), ELCR_p50=q(r.ELCR, 50),
            ELCR_p95=q(r.ELCR, 95), ELCR_p99=q(r.ELCR, 99),
            P_ELCR_gt_1e6=float((r.ELCR > thresholds["tr_low"]).mean()),
            P_ELCR_gt_1e4=float((r.ELCR > thresholds["tr_high"]).mean()),
        ))
    return pd.DataFrame(rows)


def rank_drivers(r: MCResult, metric: str = "HI") -> pd.Series:
    """Spearman rank correlation of each sampled input with HI or ELCR."""
    y = pd.Series(getattr(r, metric)).rank()
    out = {}
    for k, v in r.inputs.items():
        if np.ptp(v) == 0:
            continue
        out[k] = float(pd.Series(v).rank().corr(y))
    return pd.Series(out).sort_values(key=np.abs, ascending=False)
