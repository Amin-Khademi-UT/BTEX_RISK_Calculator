"""Reading concentration data, unit conversion and EPC statistics."""
from __future__ import annotations

from typing import Mapping

import numpy as np
import pandas as pd
from scipy import stats

from .toxicity import canonical_name

R_KPA_L = 8.314462618  # L*kPa/(mol*K)


def molar_volume_l(temperature_c: float, pressure_kpa: float) -> float:
    """Molar volume of an ideal gas (L/mol); 24.465 at 25 C and 101.325 kPa."""
    return R_KPA_L * (temperature_c + 273.15) / pressure_kpa


_UNIT_ALIASES = {
    "ug/m3": "ug/m3", "µg/m3": "ug/m3", "μg/m3": "ug/m3", "ug/m^3": "ug/m3",
    "µg/m³": "ug/m3", "μg/m³": "ug/m3", "ug/m³": "ug/m3",
    "mg/m3": "mg/m3", "mg/m³": "mg/m3",
    "ng/m3": "ng/m3", "ng/m³": "ng/m3",
    "ppb": "ppb", "ppbv": "ppb", "ppm": "ppm", "ppmv": "ppm",
}


def to_ugm3(value, unit: str, mw: float, vm: float):
    u = _UNIT_ALIASES.get(str(unit).strip().lower().replace(" ", ""))
    if u is None:
        raise ValueError(f"Unsupported unit '{unit}'. Use ug/m3, mg/m3, ng/m3, ppb or ppm.")
    if u == "ug/m3":
        return value
    if u == "mg/m3":
        return value * 1e3
    if u == "ng/m3":
        return value * 1e-3
    if u == "ppb":
        return value * mw / vm
    return value * 1e3 * mw / vm  # ppm


def _truthy(x) -> bool:
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    return str(x).strip().lower() in {"1", "true", "yes", "y", "nd", "<dl", "t"}


def read_concentrations(path, in_cfg: Mapping, compounds) -> pd.DataFrame:
    """Read a long-format CSV and return one row per sample in ug/m3.

    Required columns : site, compound, concentration
    Optional columns : sample_id, unit, nondetect, detection_limit
    """
    df = pd.read_csv(path, comment="#")
    df.columns = [c.strip().lower() for c in df.columns]
    missing = {"site", "compound"} - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required column(s): {sorted(missing)}")
    if "concentration" not in df.columns:
        df["concentration"] = np.nan
    if "sample_id" not in df.columns:
        df["sample_id"] = np.arange(len(df))
    if "unit" not in df.columns:
        df["unit"] = in_cfg["default_unit"]
    df["unit"] = df["unit"].fillna(in_cfg["default_unit"])
    if "nondetect" not in df.columns:
        df["nondetect"] = False
    df["nondetect"] = df["nondetect"].map(_truthy)
    if "detection_limit" not in df.columns:
        df["detection_limit"] = np.nan

    df["site"] = df["site"].astype(str).str.strip()
    df["compound"] = [canonical_name(c, compounds) for c in df["compound"]]

    vm = molar_volume_l(in_cfg["temperature_c"], in_cfg["pressure_kpa"])
    factor = float(in_cfg["nondetect_factor"])
    vals = []
    for _, r in df.iterrows():
        mw = compounds[r["compound"]].mw
        if r["nondetect"]:
            base = r["detection_limit"] if pd.notna(r["detection_limit"]) else r["concentration"]
            if pd.isna(base):
                raise ValueError(f"Non-detect without a detection limit (site={r['site']}).")
            vals.append(to_ugm3(float(base) * factor, r["unit"], mw, vm))
        else:
            if pd.isna(r["concentration"]):
                raise ValueError(f"Missing concentration (site={r['site']}, {r['compound']}).")
            vals.append(to_ugm3(float(r["concentration"]), r["unit"], mw, vm))
    df["conc_ugm3"] = vals
    if (df["conc_ugm3"] < 0).any():
        raise ValueError("Negative concentrations found.")

    keep = in_cfg.get("sites")
    if keep:
        df = df[df["site"].isin([str(s) for s in keep])]
        if df.empty:
            raise ValueError("`input.sites` filtered out every row.")
    return df[["site", "sample_id", "compound", "conc_ugm3", "nondetect"]].reset_index(drop=True)


def _ucl95(x: np.ndarray) -> float:
    n = len(x)
    if n == 1:
        return float(x[0])
    if n == 2:
        return float(x.max())
    m, s = x.mean(), x.std(ddof=1)
    ucl = m + stats.t.ppf(0.95, n - 1) * s / np.sqrt(n)
    return float(min(ucl, x.max()))   # EPA: never exceed the maximum detected value


def _lcl95(x: np.ndarray) -> float:
    n = len(x)
    if n < 3:
        return float(x.min())
    m, sd = x.mean(), x.std(ddof=1)
    return float(max(m - stats.t.ppf(0.95, n - 1) * sd / np.sqrt(n), x.min()))


def summarize_epc(conc: pd.DataFrame, statistic: str) -> pd.DataFrame:
    """Exposure-point concentrations (EPC) and descriptive statistics."""
    statistic = statistic.lower()
    if statistic not in {"ucl95", "mean", "median", "p95", "max"}:
        raise ValueError("input.statistic must be one of ucl95, mean, median, p95, max")
    rows = []
    for (site, comp), g in conc.groupby(["site", "compound"], sort=False):
        x = g["conc_ugm3"].to_numpy(float)
        n = len(x)
        pos = x[x > 0]
        sdlog = float(np.std(np.log(pos), ddof=1)) if len(pos) >= 3 else np.nan
        rec = dict(
            site=site, compound=comp, n=n, n_nd=int(g["nondetect"].sum()),
            mean=float(x.mean()), sd=float(x.std(ddof=1)) if n > 1 else np.nan,
            median=float(np.median(x)), p95=float(np.percentile(x, 95)),
            max=float(x.max()), min=float(x.min()), ucl95=_ucl95(x), lcl95=_lcl95(x), sdlog=sdlog,
        )
        rec["epc"] = rec[statistic]
        rec["epc_stat"] = statistic
        rows.append(rec)
    return pd.DataFrame(rows).set_index(["site", "compound"])
