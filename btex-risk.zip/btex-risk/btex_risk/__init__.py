"""btex-risk: configurable BTEX inhalation health-risk calculator.

Implements the inhalation methodology of EPA RAGS Part F (2009) as used by the
Risk Assessment Information System (RAIS):

    EC   = CA * ET * EF * ED / AT          (ug/m3)
    HQ   = EC / (RfC * 1000)
    ELCR = EC * IUR

Quick start::

    from btex_risk import run
    results = run("configs/default.yaml")
"""
from .pipeline import run, Results  # noqa: F401

__version__ = "1.0.0"
__all__ = ["run", "Results", "__version__"]
