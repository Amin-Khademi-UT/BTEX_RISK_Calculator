"""Exposure scenarios and the RAGS Part F / RAIS inhalation equations.

    EC   = CA * ET * EF * ED / AT                    [ug/m3]
    AT   = ED * 365 * 24   (non-cancer)   [hours]
    AT   = LT * 365 * 24   (cancer)       [hours]
    HQ   = EC / (RfC * 1000)
    ELCR = EC * IUR

Units: CA ug/m3, ET h/day, EF days/year, ED years, LT years, RfC mg/m3,
IUR (ug/m3)^-1.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, Mapping, Optional

import numpy as np
import pandas as pd

HOURS_PER_YEAR = 365.0 * 24.0

# --------------------------------------------------------------------------
# Parameter specification (fixed value or distribution for Monte Carlo)
# --------------------------------------------------------------------------
_DIST_POINT = {
    "fixed": lambda p: p["value"],
    "uniform": lambda p: 0.5 * (p["min"] + p["max"]),
    "triangular": lambda p: p["mode"],
    "normal": lambda p: p["mean"],
    "lognormal": lambda p: p["gm"],
}


@dataclass
class ParamSpec:
    """A scalar parameter. ``value`` is the point estimate used in the
    deterministic (RME) calculation; ``dist`` + ``params`` describe its
    distribution in the Monte Carlo analysis."""
    value: float
    dist: str = "fixed"
    params: dict = field(default_factory=dict)

    @classmethod
    def parse(cls, raw, name: str = "parameter") -> "ParamSpec":
        if isinstance(raw, ParamSpec):
            return raw
        if isinstance(raw, (int, float)):
            return cls(float(raw))
        if not isinstance(raw, Mapping):
            raise ValueError(f"{name}: expected a number or a mapping, got {raw!r}")
        raw = dict(raw)
        dist = str(raw.pop("dist", "fixed")).lower()
        if dist not in _DIST_POINT:
            raise ValueError(f"{name}: unknown dist '{dist}' (use {sorted(_DIST_POINT)})")
        value = raw.pop("value", None)
        if value is None:
            try:
                value = _DIST_POINT[dist](raw if dist != "fixed" else {"value": None})
            except KeyError as e:
                raise ValueError(f"{name}: distribution '{dist}' is missing parameter {e}") from None
        if value is None:
            raise ValueError(f"{name}: provide `value` (point estimate).")
        return cls(float(value), dist, raw)

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        p, d = self.params, self.dist
        if d == "fixed":
            x = np.full(n, self.value)
        elif d == "uniform":
            x = rng.uniform(p["min"], p["max"], n)
        elif d == "triangular":
            x = rng.triangular(p["min"], p["mode"], p["max"], n)
        elif d == "normal":
            x = rng.normal(p["mean"], p["sd"], n)
        elif d == "lognormal":
            x = np.exp(rng.normal(np.log(p["gm"]), np.log(p["gsd"]), n))
        else:  # pragma: no cover
            raise ValueError(d)
        lo, hi = p.get("lower"), p.get("upper")
        if lo is not None or hi is not None:
            x = np.clip(x, lo, hi)
        return x


# --------------------------------------------------------------------------
# Scenarios
# --------------------------------------------------------------------------
@dataclass
class Scenario:
    name: str
    ET: ParamSpec          # exposure time, hours/day
    EF: ParamSpec          # exposure frequency, days/year
    ED: ParamSpec          # exposure duration, years
    LT: float = 70.0       # lifetime for carcinogens, years
    label: str = ""
    description: str = ""

    @property
    def display(self) -> str:
        return self.label or self.name.replace("_", " ").title()

    # ---- point-estimate factors (EC = CA * factor) ------------------------
    def factor_nc(self) -> float:
        ET, EF, ED = self.ET.value, self.EF.value, self.ED.value
        return ET * EF * ED / (ED * HOURS_PER_YEAR)

    def factor_c(self) -> float:
        ET, EF, ED = self.ET.value, self.EF.value, self.ED.value
        return ET * EF * ED / (self.LT * HOURS_PER_YEAR)


# RAIS / RSL default RME inhalation exposure factors.
PRESETS: Dict[str, dict] = {
    "resident":       dict(ET=24, EF=350, ED=26, LT=70, label="Resident (child + adult, 26 y)",
                           description="RAIS/RSL residential air default"),
    "resident_adult": dict(ET=24, EF=350, ED=20, LT=70, label="Resident adult (20 y)",
                           description="RAIS/RSL residential air, adult segment"),
    "resident_child": dict(ET=24, EF=350, ED=6, LT=70, label="Resident child (6 y)",
                           description="RAIS/RSL residential air, child segment"),
    "worker":         dict(ET=8, EF=250, ED=25, LT=70, label="Composite worker (25 y)",
                           description="RAIS/RSL composite worker (industrial) air default"),
}


def parse_scenarios(cfg: Mapping) -> Dict[str, Scenario]:
    default_lt = float(cfg.get("life_time_years", 70))
    out: Dict[str, Scenario] = {}
    for name, raw in (cfg.get("scenarios") or {}).items():
        raw = dict(raw or {})
        base = dict(PRESETS.get(raw.pop("preset", None) or "", {}))
        base.update(raw)
        for key in ("ET", "EF", "ED"):
            if key not in base:
                raise ValueError(f"scenario '{name}': missing {key} (or use `preset:`).")
        out[name] = Scenario(
            name=name,
            ET=ParamSpec.parse(base["ET"], f"{name}.ET"),
            EF=ParamSpec.parse(base["EF"], f"{name}.EF"),
            ED=ParamSpec.parse(base["ED"], f"{name}.ED"),
            LT=float(base.get("LT", default_lt)),
            label=base.get("label", ""),
            description=base.get("description", ""),
        )
    if not out:
        raise ValueError("No scenarios defined.")
    return out


# --------------------------------------------------------------------------
# Core calculations
# --------------------------------------------------------------------------
def exposure_concentration(ca, ET, EF, ED, AT_hours):
    """EC = CA * ET * EF * ED / AT  (vectorised)."""
    return np.asarray(ca) * ET * EF * ED / AT_hours


def compute_risk(epc: pd.DataFrame, scenarios: Mapping[str, Scenario], compounds) -> pd.DataFrame:
    """Deterministic (point-estimate) risk for every site x compound x scenario.

    ``epc`` must have a MultiIndex (site, compound) and a column ``epc``
    (exposure-point concentration, ug/m3).
    """
    rows = []
    for (site, comp), rec in epc.iterrows():
        c = compounds[comp]
        ca = float(rec["epc"])
        for sname, s in scenarios.items():
            at_nc = s.ED.value * HOURS_PER_YEAR
            at_c = s.LT * HOURS_PER_YEAR
            ec_nc = exposure_concentration(ca, s.ET.value, s.EF.value, s.ED.value, at_nc)
            ec_c = exposure_concentration(ca, s.ET.value, s.EF.value, s.ED.value, at_c)
            hq = ec_nc / (c.rfc * 1000.0) if c.rfc else np.nan
            elcr = ec_c * c.iur if c.iur else np.nan
            rows.append(dict(
                site=site, compound=comp, scenario=sname, CA=ca,
                EC_nc=float(ec_nc), EC_c=float(ec_c),
                RfC=c.rfc if c.rfc else np.nan, IUR=c.iur if c.iur else np.nan,
                HQ=float(hq), ELCR=float(elcr), target_organ=c.target_organ,
            ))
    return pd.DataFrame(rows)


def aggregate(risk: pd.DataFrame) -> pd.DataFrame:
    """Per site x scenario: Hazard Index, target-organ HIs, total ELCR, drivers."""
    out = []
    for (site, scen), g in risk.groupby(["site", "scenario"], sort=False):
        hi = g["HQ"].sum(skipna=True)
        by_organ = g.groupby("target_organ")["HQ"].sum(min_count=1).dropna()
        top_organ = by_organ.idxmax() if len(by_organ) else ""
        elcr = g["ELCR"].sum(skipna=True)
        hq_driver = g.loc[g["HQ"].idxmax(), "compound"] if g["HQ"].notna().any() else ""
        cr_driver = g.loc[g["ELCR"].idxmax(), "compound"] if g["ELCR"].notna().any() else ""
        out.append(dict(
            site=site, scenario=scen, HI=hi, HI_max_organ=by_organ.max() if len(by_organ) else np.nan,
            HI_max_organ_name=top_organ, ELCR=elcr, HQ_driver=hq_driver, ELCR_driver=cr_driver,
        ))
    return pd.DataFrame(out)


def screening_levels(compounds, scenarios, target_risk=1e-6, target_hq=1.0) -> pd.DataFrame:
    """Risk-based screening concentrations (ug/m3) for each compound x scenario.

        SL_cancer    = TR / (IUR * f_c)
        SL_noncancer = THQ * RfC * 1000 / f_nc
    where f = ET*EF*ED / AT. For benzene these reproduce the EPA RSL air
    values (resident 0.36 ug/m3 cancer; composite worker 1.6 ug/m3).
    """
    rows = []
    for key, c in compounds.items():
        for sname, s in scenarios.items():
            sl_c = target_risk / (c.iur * s.factor_c()) if c.iur else np.nan
            sl_nc = target_hq * c.rfc * 1000.0 / s.factor_nc() if c.rfc else np.nan
            rows.append(dict(compound=key, scenario=sname,
                             SL_cancer_ugm3=sl_c, SL_noncancer_ugm3=sl_nc,
                             SL_ugm3=np.nanmin([sl_c, sl_nc])))
    return pd.DataFrame(rows)
