"""End-to-end pipeline: config -> EPC -> risk -> Monte Carlo -> sensitivity -> charts."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd

from . import exposure, io, montecarlo, sensitivity
from .config import load_config, resolve_path
from .toxicity import build_compounds


@dataclass
class Results:
    cfg: dict
    compounds: dict
    scenarios: dict
    conc: pd.DataFrame
    epc: pd.DataFrame
    risk: pd.DataFrame
    agg: pd.DataFrame
    screening: pd.DataFrame
    mc: Dict[tuple, montecarlo.MCResult] = field(default_factory=dict)
    mc_summary: Optional[pd.DataFrame] = None
    sens: Optional[pd.DataFrame] = None
    focus_site: str = ""
    focus_scenario: str = ""
    output_dir: Optional[Path] = None
    files: list = field(default_factory=list)


def _pick_focus(cfg, agg, scenarios):
    scen = cfg["plots"].get("focus_scenario") or next(iter(scenarios))
    if scen not in scenarios:
        raise ValueError(f"plots.focus_scenario '{scen}' is not a defined scenario.")
    site = cfg["plots"].get("focus_site")
    if site is None:
        a = agg[agg.scenario == scen]
        site = a.sort_values(["ELCR", "HI"], ascending=False).iloc[0]["site"]
    if site not in set(agg.site):
        raise ValueError(f"plots.focus_site '{site}' not found in data.")
    return str(site), scen


def run(config_path: Optional[str] = None, overrides: Optional[dict] = None, make_outputs: bool = True) -> Results:
    cfg = load_config(config_path, overrides)
    compounds = build_compounds(cfg["toxicity"])
    scenarios = exposure.parse_scenarios(cfg)

    csv = resolve_path(cfg, cfg["input"]["concentrations_csv"])
    conc = io.read_concentrations(csv, cfg["input"], compounds)
    epc = io.summarize_epc(conc, cfg["input"]["statistic"])
    used = [c for c in compounds if c in set(conc.compound)]
    compounds_used = {c: compounds[c] for c in used}

    risk = exposure.compute_risk(epc, scenarios, compounds)
    agg = exposure.aggregate(risk)
    screening = exposure.screening_levels(
        compounds_used, scenarios, cfg["thresholds"]["tr_low"], cfg["thresholds"]["hq"])
    res = Results(cfg, compounds_used, scenarios, conc, epc, risk, agg, screening)
    res.focus_site, res.focus_scenario = _pick_focus(cfg, agg, scenarios)

    th = cfg["thresholds"]
    if cfg["monte_carlo"]["enabled"]:
        res.mc = montecarlo.run_monte_carlo(epc, scenarios, compounds, cfg["monte_carlo"])
        res.mc_summary = montecarlo.summarize(res.mc, th)
    if cfg["sensitivity"]["enabled"]:
        res.sens = sensitivity.oat(epc.loc[res.focus_site], scenarios[res.focus_scenario], compounds,
                                   cfg["sensitivity"]["variation"], cfg["sensitivity"].get("ranges"))
    if make_outputs:
        write_outputs(res)
    return res


def write_outputs(res: Results) -> None:
    cfg = res.cfg
    out = Path(cfg["project"]["output_dir"])
    (out / "tables").mkdir(parents=True, exist_ok=True)
    res.output_dir = out
    tables = {
        "concentrations_ugm3.csv": res.conc,
        "epc_statistics.csv": res.epc.reset_index(),
        "risk_by_compound.csv": res.risk,
        "risk_summary.csv": res.agg,
        "screening_levels.csv": res.screening,
    }
    if res.mc_summary is not None:
        tables["monte_carlo_summary.csv"] = res.mc_summary
    if res.sens is not None:
        tables["sensitivity_oat.csv"] = res.sens
    for name, df in tables.items():
        p = out / "tables" / name
        df.to_csv(p, index=False, float_format="%.6g")
        res.files.append(str(p))

    meta = dict(
        project=cfg["project"]["name"],
        statistic=cfg["input"]["statistic"],
        scenarios={k: dict(ET=v.ET.value, EF=v.EF.value, ED=v.ED.value, LT=v.LT) for k, v in res.scenarios.items()},
        toxicity={k: dict(rfc_mg_m3=v.rfc, iur_per_ugm3=v.iur, target_organ=v.target_organ, source=v.source)
                  for k, v in res.compounds.items()},
        thresholds=cfg["thresholds"], focus=dict(site=res.focus_site, scenario=res.focus_scenario),
        monte_carlo=cfg["monte_carlo"],
    )
    with open(out / "run_metadata.json", "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, default=float)
    res.files.append(str(out / "run_metadata.json"))

    if cfg["plots"]["enabled"]:
        from . import report
        report.make_all(res)
