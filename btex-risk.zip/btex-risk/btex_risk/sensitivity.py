"""One-at-a-time (OAT) sensitivity analysis of the deterministic (RME) result.

Each parameter is moved to a plausible LOW and HIGH value while the others stay
at their base value:

* CA  : 95 % lower confidence limit of the mean -> maximum measured value
* ET, EF, ED : P5-P95 of their Monte Carlo distribution if one is defined,
               otherwise +/- ``variation``; or explicit ``sensitivity.ranges``
* LT, RfC, IUR : +/- ``variation``

Note that ED has no effect on the non-cancer HI: AT = ED x 365 x 24 cancels it.
"""
from __future__ import annotations

from typing import Mapping, Optional

import numpy as np
import pandas as pd

from .exposure import HOURS_PER_YEAR, ParamSpec, Scenario


def _totals(ca: Mapping[str, float], vals: Mapping[str, float], compounds, k_rfc=1.0, k_iur=1.0):
    ET, EF, ED, LT = vals["ET"], vals["EF"], vals["ED"], vals["LT"]
    hi = elcr = 0.0
    for comp, x in ca.items():
        c = compounds[comp]
        if c.rfc:
            hi += x * ET * EF * ED / (ED * HOURS_PER_YEAR) / (c.rfc * k_rfc * 1000.0)
        if c.iur:
            elcr += x * ET * EF * ED / (LT * HOURS_PER_YEAR) * c.iur * k_iur
    return hi, elcr


def _range(spec: ParamSpec, name: str, variation: float, user: Optional[Mapping]):
    if user and name in user:
        lo, hi = map(float, user[name])
        return lo, hi, f"{lo:g}\u2013{hi:g}"
    if spec.dist != "fixed":
        s = spec.sample(20000, np.random.default_rng(7))
        lo, hi = float(np.percentile(s, 5)), float(np.percentile(s, 95))
        return lo, hi, f"P5\u2013P95: {lo:.3g}\u2013{hi:.3g}"
    lo, hi = spec.value * (1 - variation), spec.value * (1 + variation)
    return lo, hi, f"\u00b1{variation:.0%}"


def oat(epc_site: pd.DataFrame, scen: Scenario, compounds, variation: float = 0.2,
        user_ranges: Optional[Mapping] = None) -> pd.DataFrame:
    base_ca = epc_site["epc"].to_dict()
    base = dict(ET=scen.ET.value, EF=scen.EF.value, ED=scen.ED.value, LT=scen.LT)
    b_hi, b_c = _totals(base_ca, base, compounds)
    rows = []

    def add(label, rng_txt, lo, hi, on_hi, on_c):
        rows.append(dict(parameter=label, range=rng_txt, base_HI=b_hi, HI_low=lo[0], HI_high=hi[0],
                         base_ELCR=b_c, ELCR_low=lo[1], ELCR_high=hi[1], on_HI=on_hi, on_ELCR=on_c))

    # concentration
    lo_ca = epc_site["lcl95"].to_dict()
    hi_ca = epc_site["max"].to_dict()
    add("Concentration (CA)", "LCL95 \u2192 max", _totals(lo_ca, base, compounds), _totals(hi_ca, base, compounds),
        True, True)
    for key, label, spec, on_hi in (("ET", "Exposure time (ET)", scen.ET, True),
                                    ("EF", "Exposure frequency (EF)", scen.EF, True),
                                    ("ED", "Exposure duration (ED)", scen.ED, True)):
        lo, hi, txt = _range(spec, key, variation, user_ranges)
        add(label, txt, _totals(base_ca, {**base, key: lo}, compounds),
            _totals(base_ca, {**base, key: hi}, compounds), on_hi, True)
    lt_lo, lt_hi = scen.LT * (1 - variation), scen.LT * (1 + variation)
    if user_ranges and "LT" in user_ranges:
        lt_lo, lt_hi = map(float, user_ranges["LT"])
    add("Lifetime (LT)", f"{lt_lo:g}\u2013{lt_hi:g} y", _totals(base_ca, {**base, "LT": lt_lo}, compounds),
        _totals(base_ca, {**base, "LT": lt_hi}, compounds), False, True)
    add("Reference conc. (RfC)", f"\u00b1{variation:.0%}", _totals(base_ca, base, compounds, k_rfc=1 - variation),
        _totals(base_ca, base, compounds, k_rfc=1 + variation), True, False)
    add("Unit risk (IUR)", f"\u00b1{variation:.0%}", _totals(base_ca, base, compounds, k_iur=1 - variation),
        _totals(base_ca, base, compounds, k_iur=1 + variation), False, True)
    return pd.DataFrame(rows)
